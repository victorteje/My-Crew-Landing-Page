let estado1 = document.querySelector("#circulo1")
function Feliz1 () {
    estado1.style.background= "forestgreen";
}

function Triste1 () {
    estado1.style.background= "red";
}

let estado2 = document.querySelector("#circulo2")
function Feliz2 () {
    estado2.style.background= "forestgreen";
}

function Triste2 () {
    estado2.style.background= "red";
}

let estado3 = document.querySelector("#circulo3")
function Feliz3 () {
    estado3.style.background= "forestgreen";
}

function Triste3 () {
    estado3.style.background= "red";
}

let estado4 = document.querySelector("#circulo4")
function Feliz4 () {
    estado4.style.background= "forestgreen";
}

function Triste4 () {
    estado4.style.background= "red";
}